﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class Ingredient
    {
        // Public properties for the ingredient's name, quantity, and unit of measurement
        public string Name { get; set; } // The name of the ingredient
        public double Quantity { get; set; } // The quantity of the ingredient
        public string Unit { get; set; } // The unit of measurement for the ingredient

        // Constructor for the Ingredient class
        public Ingredient(string name, double quantity, string unit)
        {
            // Assigning the provided name, quantity, and unit to the respective properties
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }
    }
}
